package Pac1;
import java.util.Scanner;
public class Lab5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the number : ");
		int num = sc.nextInt();
		if (num>0) {
			System.out.println("Positive number");
		}
		else {
		System.out.println("negative number");
			}

	}

}

