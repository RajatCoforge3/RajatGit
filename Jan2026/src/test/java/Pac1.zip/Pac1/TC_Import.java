package Pac1;

import static java.lang.Math.*;

public class TC_Import {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(sqrt(900));

	}

}
