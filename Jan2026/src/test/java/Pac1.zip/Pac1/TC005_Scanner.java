package Pac1;
import java.util.Scanner;
public class TC005_Scanner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Your name : ");
		String name = sc.nextLine();
		System.out.println("Your name is : "+name);
		

	}

}
