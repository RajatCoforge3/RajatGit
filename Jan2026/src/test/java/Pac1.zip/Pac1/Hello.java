package Pac1;

public class Hello {

	public static void main(String[] args) {
		System.out.println("First name : Rajat");
		System.out.println("Last name:Bhardwaj");
		System.out.println( "Age : 22");
		System.out.println("Weight : 92kg ");

		
		int age = 22;
		if (age>=18 & age <100) {
				System.out.println("you'r a valid voter");
		}
		else {
			System.out.println(" Not eligible for vote");
		}
	}

}
