package Pac2;
import Pac1.TC002_ControlStatements;
public class TC_Pacexample {
	public static void main(String[] args) {
		TC002_ControlStatements obj = new TC002_ControlStatements();
		
		System.out.println("number from cs : "+obj.num);
	}
}
